#!/usr/bin/env python3
"""Build an AppImage for Mark Converter.

Requirements:
    - Python 3 with venv module
    - GTK4 runtime libraries on the host
    - appimagetool (download from https://github.com/AppImage/appimagetool/releases)

Usage:
    python3 build_appimage.py
"""

import os
import shutil
import subprocess
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from mark_converter.constants import VERSION  # noqa: E402

APP_NAME = "Mark Converter"
PACKAGE_DIR = os.path.join(BASE_DIR, "mark_converter")
ICON_SRC = os.path.join(BASE_DIR, "assets", "images", "mark-converter.png")
DESKTOP_SRC = os.path.join(BASE_DIR, "mark-converter.desktop")
BUILD_DIR = os.path.join(BASE_DIR, "AppDir")
OUTPUT = os.path.join(BASE_DIR, f"MarkConverter-{VERSION}-x86_64.AppImage")


def run(cmd: list[str], **kwargs) -> None:
    """Run a command in the build directory, failing on any error."""
    print(f"  $ {' '.join(cmd)}")
    subprocess.run(cmd, check=True, cwd=BASE_DIR, **kwargs)


def step(msg: str) -> None:
    """Print a section heading to the build log."""
    print(f"\n==> {msg}")


def clean() -> None:
    """Remove any previous build directory and all stale AppImages."""
    step("Cleaning old builds")
    for p in (BUILD_DIR, OUTPUT):
        if os.path.isdir(p):
            shutil.rmtree(p)
        elif os.path.isfile(p):
            os.remove(p)
    for f in os.scandir(BASE_DIR):
        if (
            f.name.startswith("MarkConverter-")
            and f.name.endswith(".AppImage")
            and f.is_file()
        ):
            os.remove(f.path)


def create_appdir() -> None:
    """Assemble the AppDir layout with package files, wrapper, icon and desktop."""
    step("Creating AppDir structure")

    for d in [
        os.path.join(BUILD_DIR, "usr", "bin"),
        os.path.join(BUILD_DIR, "usr", "share", "mark_converter"),
        os.path.join(BUILD_DIR, "usr", "share", "icons", "hicolor", "256x256", "apps"),
    ]:
        os.makedirs(d, exist_ok=True)

    for f in os.listdir(PACKAGE_DIR):
        if f.endswith(".py") or f.endswith(".css"):
            shutil.copy2(
                os.path.join(PACKAGE_DIR, f),
                os.path.join(BUILD_DIR, "usr", "share", "mark_converter", f),
            )

    shutil.copy2(
        os.path.join(BASE_DIR, "requirements.txt"),
        os.path.join(BUILD_DIR, "usr", "share", "requirements.txt"),
    )

    wrapper = os.path.join(BUILD_DIR, "usr", "bin", "mark-converter")
    with open(wrapper, "w") as f:
        f.write("#!/bin/bash\n")
        f.write('DIR="$(dirname "$(readlink -f "$0")")"\n')
        f.write('SHARE_DIR="$(dirname "$DIR")/share"\n')
        f.write('export PYTHONPATH="$SHARE_DIR:$PYTHONPATH"\n')
        f.write('cd "$SHARE_DIR"\n')
        f.write('exec python3 -m mark_converter.main "$@"\n')
    os.chmod(wrapper, 0o755)

    icons_apps = os.path.join(
        BUILD_DIR, "usr", "share", "icons", "hicolor", "256x256", "apps"
    )
    shutil.copy2(ICON_SRC, os.path.join(icons_apps, "mark-converter.png"))
    shutil.copy2(ICON_SRC, os.path.join(BUILD_DIR, "mark-converter.png"))

    with open(DESKTOP_SRC) as f:
        desktop = f.read()
    with open(os.path.join(BUILD_DIR, "mark-converter.desktop"), "w") as f:
        f.write(desktop)

    apprun = os.path.join(BUILD_DIR, "AppRun")
    os.symlink("usr/bin/mark-converter", apprun)

    print(f"  AppDir created at {BUILD_DIR}")


def build_appimage() -> None:
    """Locate appimagetool and package the AppDir into the output AppImage."""
    step("Building AppImage")
    tool = shutil.which("appimagetool")
    if not tool:
        tool = os.path.join(BASE_DIR, "appimagetool")
    if not os.path.isfile(tool):
        print("ERROR: appimagetool not found.")
        print("  Download from: https://github.com/AppImage/appimagetool/releases")
        print("  Or place it in the project directory as 'appimagetool'")
        sys.exit(1)

    env = os.environ.copy()
    env["ARCH"] = "x86_64"
    run([tool, "--no-appstream", BUILD_DIR, OUTPUT], env=env)
    size_mb = os.path.getsize(OUTPUT) / (1024 * 1024)
    print(f"\n  Built: {OUTPUT}")
    print(f"  Size:  {size_mb:.1f} MB")


def main() -> None:
    """Run the full AppImage build: clean, assemble AppDir, and package."""
    print(f"Building {APP_NAME} AppImage v{VERSION}")
    clean()
    create_appdir()
    build_appimage()


if __name__ == "__main__":
    main()
